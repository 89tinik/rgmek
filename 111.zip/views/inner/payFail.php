<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Ошибка оплаты | ЛК РГМЭК';
?>
<div class="page-heading">
    <h1 class="title">Ошибка при оплате.</h1>
</div>
<div class="h-titles">
    <div class="h-subtitle">
        Попробуйте оплатить ещё раз.
    </div>
</div>