<?php
/* @var $content string */
?>
<?=$content;?>