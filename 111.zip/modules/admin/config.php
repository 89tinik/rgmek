<?php
return [
    'layout' => 'admin',
];