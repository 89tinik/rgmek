<?php
/* @var $fields */
use yii\helpers\Html;
?>
<p>PUID:<b><?=$fields['puid']?></b> </p>

