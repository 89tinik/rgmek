<?php
/* @var $fields */
use yii\helpers\Html;
?>
<p>Пользователь:<b><?=$fields['user']?></b> </p>
<p>Договора:<b><?=$fields['contracts']?></b> </p>
<p>Имя:<b><?=$fields['name']?></b> </p>
<p>Телефон:<b><?=$fields['phone']?></b> </p>
<p>E-mail:<b><?=$fields['email']?></b> </p>
<p>Сообщение:<b><?=$fields['body']?></b> </p>

