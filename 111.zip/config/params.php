<?php

return [
    'adminEmail' => 'lk@rgmek.ru',
    'senderEmail' => 'noreply@rgmek.ru',
    'senderName' => 'Example.com mailer',
];
